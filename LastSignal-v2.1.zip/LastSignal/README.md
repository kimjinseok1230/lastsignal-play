# Last Signal

A browser-native JavaScript survival roguelike. Chapter II: Interference. No build step, dependencies, backend, paid assets, or API keys. Serve `dist/` with any HTTP server; ES modules require HTTP rather than opening the HTML through `file://`.

## Play

Move with WASD or arrows. Move the mouse to aim; weapons keep firing without clicking, including when no enemy is nearby. Movement and dash direction stay independent of aim. Space dashes with invulnerability; E clears nearby bullets, damages enemies and exposes bosses. Q spends 100 resonance for seven seconds of overdrive: 35% more damage and firing speed, with 30% more incoming damage. Timely dodges restore 3 health and 18 resonance. Escape or P pauses. Choose level-up upgrades using 1/2/3 or the pointer. Mobile devices have independent left movement and right aiming sticks, plus all three ability buttons. Releasing the aiming stick retains its last direction. Primary fire and rail beams follow aim; rockets and the first arc select targets in front, while drones and fields defend the surrounding area.

Restore relays appearing at 1, 4, and 7 minutes by staying within their circles for 12 cumulative seconds. Defeat the final boss arriving at 14 minutes. From 15 minutes, return to the central extraction point and stay for five seconds. Incomplete objectives keep the encounter running in overtime.

Three starting operators, nine regular enemy types, elites, three boss encounters, 17 upgrade types, six auxiliary weapons and six weapon evolutions. Choose up to three auxiliary weapons alongside the starting weapon. A mandatory level-8 mutation gives a permanent tradeoff for that run. Cold plus lightning shatters enemies, rockets burn, rail beams penetrate jammer protection and evolved gravity traps leave pulling wells. Laser crossfire, flanking packs and closing waves recur with increasing frequency. Boss patterns change at 66% and 33% health. Relays now attract a defending pack.

Two rerolls per run, permanent upgrades, run history, and an unlockable harder mode. In-progress runs autosave locally every 20 seconds, at upgrade choices, and when pausing or leaving the page. Storage is device/browser-local and never sent to a server. The original storage keys and format version remain compatible. Old runs with four auxiliary weapons keep all four; current runs retain their mutation, patterns, resonance and pending choices.

## Files

- `dist/game.js`: base fixed-step simulation, collision, items, serialization, and reusable Canvas paths.
- `dist/aim.js` and `dist/aim.css`: mouse aiming, two independent touch pointers, forward target selection and aim indicators.
- `dist/interference.js`: Chapter II enemy patterns, weapon slots, mutations, resonance, elemental interactions, balance, and save migration.
- `dist/signal-visuals.js`: distinctive operator, enemy silhouettes, weapon effects, warnings, and engraved radio-themed arena.
- `dist/app.js`: interface, persistence, input, sound settings, and animation loop.
- `dist/data.js`: balance values and upgrade definitions.
- `dist/audio.js`: original synthesized effects and ambient pulse, generated with Web Audio.
- `dist/style.css` and `dist/interference.css`: responsive game interface and phosphor/oxidized-metal theme.
- `dist/assets/signal-floor.png`: generated basalt, copper and radio-circuit arena artwork, integrated with Canvas markings.

Gameplay graphics use Canvas. Fonts use Google Fonts when available, with system fallbacks. Game logic and assets otherwise have no external runtime dependency.

## Verification

Run `node tests/simulation.mjs` and `node tests/interference.mjs`, plus `node tests/aim.mjs` for combat rules, progression, evolution conditions, save compatibility and finite Canvas arguments. The full-timeline route uses invulnerability only to verify every encounter and the actual final-boss/extraction gates; it is not a difficulty test. `node tests/balance.mjs` separately probes stationary and reactive pilots with real damage, legal upgrade choices and no permanent upgrades. Those automated pilots do not establish human win rates. No browser or screenshot QA was performed for this update.
