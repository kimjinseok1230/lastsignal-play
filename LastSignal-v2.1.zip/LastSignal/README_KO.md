# Last Signal v2.1 실행 안내

마우스 조준과 자동 연사가 반영된 최신 게임입니다.
전체 JavaScript·HTML·CSS 소스, 그래픽 이미지, 검증 스크립트를 포함합니다.

## 실행

1. ZIP 압축을 풀고 LastSignal 폴더를 엽니다.
2. Python이 설치된 환경에서 이 폴더를 기준으로 다음 명령을 실행합니다.

```sh
python -m http.server 8080 --bind 127.0.0.1 --directory dist
```

Windows에서 python 명령을 사용할 수 없다면 Python 런처로 실행할 수 있습니다.

```sh
py -3 -m http.server 8080 --bind 127.0.0.1 --directory dist
```

3. 브라우저에서 http://127.0.0.1:8080 을 엽니다.
4. 서버를 종료하려면 명령 창에서 Ctrl+C를 누릅니다.

ES 모듈을 사용하므로 index.html을 직접 더블클릭하는 대신 HTTP 서버로 실행하세요.
다른 정적 호스팅 서비스를 사용할 때는 dist 폴더를 게시 경로로 설정하면 됩니다.

## 조작

- 이동: WASD / 방향키
- 조준: 마우스 이동
- 공격: 클릭 없이 계속 자동 발사
- 대시: Space
- 전자기 펄스: E
- 과부하: 공명 100%에서 Q
- 일시정지: Esc / P
- 강화 선택: 1 / 2 / 3
- 모바일: 왼쪽 스틱 이동, 오른쪽 스틱 조준, 아래 버튼으로 스킬 사용

중계기 3개 복구 → 최후의 감시자 처치 → 15분부터 중앙에서 5초 생존해 탈출합니다.
진행 기록과 기지 강화는 접속한 브라우저에 저장됩니다.
기존 공개 사이트의 저장 기록은 로컬 실행 주소와 별도로 보관됩니다.

## 파일 구성

- dist/: 실제 게임과 이미지
- tests/: Node.js로 실행하는 전투·진행·조준 검증
- README.md: 상세 구조와 게임 설명

## 검증 실행

Node.js가 설치된 경우 LastSignal 폴더에서 실행하세요.

```sh
node tests/aim.mjs
node tests/interference.mjs
node tests/simulation.mjs
```

원본 코드 커밋: 755f315f0008d09a0eb45e480bc4c24cbaeefbfa
