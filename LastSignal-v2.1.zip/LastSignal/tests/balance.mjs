// Reproducible balance probe, not a claim about human win rates.
// The pilot receives real damage and chooses only upgrades actually offered.
import {SignalGame} from '../dist/interference.js';
import {createMeta,EVOLUTIONS,WEAPONS} from '../dist/data.js';
const length=(x,y)=>Math.hypot(x,y);
const distance=(a,b)=>length(a.x-b.x,a.y-b.y);
function segment(p,a,b){const dx=b.x-a.x,dy=b.y-a.y;const q=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1)));return length(p.x-a.x-dx*q,p.y-a.y-dy*q);}
const angleDiff=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
function run(classId,active){
  const g=new SignalGame({getContext:()=>null},{},{play(){},ambient(){}},{particles:false,shake:false});g.start(classId,createMeta());g.rng=93757;let result=null,peak=0;g.callbacks.finish=r=>result=r;
  const priorities=['bastion','capacitor','glass','power','rail','field','arc','haste','magnet','speed','multi','pierce','crit','armor','regen','vitality','pulse','orbit','rocket','mine','overload','heal','cache'];
  for(let step=0;step<60*1200&&g.state!=='ended';step++){
    if(g.state==='upgrade'){
      const score=c=>{
        if(c.evolution)return -50;
        if(g.player.hp<g.player.maxHp*.4&&['vitality','armor','heal'].includes(c.id))return -40;
        if(WEAPONS.includes(c.id)&&!g.u[c.id]&&['rail','arc','rocket'].includes(c.id))return -12;
        const evo=EVOLUTIONS.find(e=>g.u[e.weapon]&&e.support===c.id&&!g.evolved[e.id]&&(g.u[c.id]||0)<2);
        if(evo&&g.u[evo.weapon]>=4)return -20;
        if(WEAPONS.includes(c.id)&&g.u[c.id])return -5-(g.u[c.id]||0);
        return priorities.indexOf(c.id)<0?90:priorities.indexOf(c.id);
      };
      g.choose([...g.choiceSet].sort((a,b)=>score(a)-score(b))[0].id);
    }
    const p=g.player;
    if(active&&step%8===0){
      const relay=g.relays.find(r=>!r.active&&g.t>=r.unlock),boss=g.enemies.find(e=>e.boss&&!e.dead);
      const nearestLoot=g.loot.filter(l=>l.type!=='xp'||distance(l,p)<400).sort((a,b)=>distance(a,p)-distance(b,p));
      let target=relay||nearestLoot.find(l=>(l.type==='med'&&p.hp<p.maxHp*.7)||l.type==='chest')||((g.t>=900&&g.finalDead)?{x:0,y:0}:boss?{x:boss.x+Math.cos(g.t*.09)*310,y:boss.y+Math.sin(g.t*.09)*310}:nearestLoot[0]||{x:Math.cos(g.t*.1)*400,y:Math.sin(g.t*.1)*400});
      const nearby=g.enemies.filter(e=>!e.dead&&e.warmup<.2&&distance(e,p)<300),bullets=g.hostile.filter(b=>distance(b,p)<230);
      let best={score:Infinity,x:0,y:0};
      for(let i=0;i<=24;i++){
        const a=i*Math.PI/12,x=i===24?0:Math.cos(a),y=i===24?0:Math.sin(a),q={x:p.x+x*g.stats.speed*.32,y:p.y+y*g.stats.speed*.32};
        let score=distance(q,target)*.12;
        if(Math.abs(q.x)>1500||Math.abs(q.y)>1500)score+=400;
        for(const e of nearby){const d=distance(q,e)-e.r;score+=Math.max(0,100-d)*2.8;if(d<25)score+=180;}
        for(const b of bullets){const d=segment(q,b,{x:b.x+b.vx*.35,y:b.y+b.vy*.35});if(d<30)score+=(30-d)*8;}
        for(const l of g.lines)if(l.delay<.55&&segment(q,l,l.end)<l.width/2+23)score+=260;
        for(const w of g.waves){const r=w.r-Math.max(0,.32-w.delay)*100,ang=Math.atan2(q.y-w.y,q.x-w.x);if(Math.abs(distance(q,w)-r)<35&&Math.abs(angleDiff(ang,w.gap))>w.gapWidth/2)score+=260;}
        for(const h of g.hazards)if(h.life<.6&&distance(q,h)<h.r+20)score+=250;
        if(relay&&distance(p,relay)<90&&distance(q,relay)>98)score+=15;
        if(score<best.score)best={score,x,y};
      }
      g.touch={x:best.x,y:best.y};
      const aim=g.nearest(p,g.stats.range)||boss;if(aim)g.aimVector(aim.x-p.x,aim.y-p.y);
      if(nearby.some(e=>distance(e,p)<130)||bullets.some(b=>distance(b,p)<90))g.pulse();
      const imminent=nearby.some(e=>distance(e,p)<e.r+37)||bullets.some(b=>segment(p,b,{x:b.x+b.vx*.2,y:b.y+b.vy*.2})<20)||g.lines.some(l=>l.delay<.23&&segment(p,l,l.end)<25)||g.waves.some(w=>w.delay<.1&&Math.abs(distance(p,w)-w.r)<48);
      if(imminent)g.dash();
      if(p.hp>p.maxHp*.55&&(g.enemies.length>25||boss))g.activateOverdrive();
    }
    g.update(1/60);peak=Math.max(peak,g.enemies.length);if(step%10===0){g.fx=[];g.texts=[];g.beams=[];}
  }
  return {classId,pilot:active?'reactive':'stationary',won:!!result?.won,seconds:Math.round(g.t),level:g.level,kills:g.kills,damageTaken:Math.round(g.damageTaken),peakEnemies:peak,perfectDodges:g.perfectDodges,overdrives:g.overdriveCount,relays:g.relays.filter(r=>r.active).length,weapons:WEAPONS.filter(id=>g.u[id]),evolutions:Object.keys(g.evolved)};
}
console.log(JSON.stringify([run('warden',false),run('warden',true),run('runner',true),run('engineer',true)],null,2));
