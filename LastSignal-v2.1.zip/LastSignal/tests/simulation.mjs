import assert from 'node:assert/strict';
import {SignalGame as Game} from '../dist/interference.js';
import {CLASSES,UPGRADES,EVOLUTIONS,createMeta,xpRequired} from '../dist/data.js';

// Simulation checks run in Node; these are not browser or visual tests.
let draws=0;
const context=new Proxy({}, {get:(obj,key)=>key==='createRadialGradient'?()=>({addColorStop(){}}):obj[key]??((...args)=>{draws++;for(const a of args)if(typeof a==='number')assert(Number.isFinite(a),'non-finite canvas argument in '+String(key));}),set:(obj,key,value)=>{obj[key]=value;return true;}});
const canvas={getContext:()=>context,width:1280,height:800};
const audio={play(){},ambient(){}};
const settings={particles:true,shake:true};
const make=(id='runner')=>{const g=new Game(canvas,{},audio,settings);g.resize(1280,800);g.start(id,createMeta());g.rng=93757;return g;};
const tests=[];
function check(name,fn){fn();tests.push(name);}
check('Each operator starts with usable distinct stats',()=>{for(const c of CLASSES){const g=make(c.id);assert.equal(g.player.hp,c.hp);assert(g.stats.damage>0);assert.equal(g.u.orbit||0,c.id==='engineer'?1:0);}});
check('Diagonal movement normalized; dash protects and cools down',()=>{const a=make(),b=make();a.keys.add('KeyD');b.keys.add('KeyD');b.keys.add('KeyS');a.update(1/60);b.update(1/60);assert(Math.abs(Math.hypot(a.player.x,a.player.y)-Math.hypot(b.player.x,b.player.y))<1e-7);a.player.invuln=0;const hp=a.player.hp;assert(a.dash());a.hitPlayer(50);assert.equal(a.player.hp,hp);assert(!a.dash());a.player.invuln=0;a.hitPlayer(50);assert.equal(a.player.hp,hp-50);});
check('Pulse removes nearby hostile bullets and respects cooldown',()=>{const g=make();const e=g.spawnEnemy('brute',60,0);e.warmup=0;g.hostile=[{x:40,y:0},{x:800,y:0}];g.pulse();assert(e.hp<e.maxHp);assert.equal(g.hostile.length,1);assert(!g.pulse());});
check('All six evolutions appear only after the required combo',()=>{for(const evo of EVOLUTIONS){const g=make();g.u[evo.weapon]=5;g.u[evo.support]=1;assert(!g.getChoices().some(c=>c.id===evo.id));g.u[evo.support]=2;assert(g.getChoices().some(c=>c.id===evo.id));g.applyUpgrade(evo.id);assert(g.evolved[evo.id]);assert(!g.getChoices().some(c=>c.id===evo.id));}});
check('Experience overflow, mandatory choices, finite fallback, reroll limits',()=>{const g=make();g.addXp(xpRequired(1)+xpRequired(2)+5);assert.equal(g.level,3);assert.equal(g.xp,5);assert.equal(g.pendingLevels,2);g.levelUp();g.choose(g.choiceSet[0].id);assert.equal(g.state,'upgrade');g.choose(g.choiceSet[0].id);assert.equal(g.state,'playing');for(const u of UPGRADES)g.u[u.id]=u.max;for(const e of EVOLUTIONS)g.evolved[e.id]=true;assert.equal(g.getChoices().length,3);g.pendingLevels=1;g.levelUp();g.reroll();g.reroll();assert(!g.reroll());});
check('Relay progress persists away from its circle and rewards exactly once',()=>{const g=make();g.t=70;g.player.x=g.relays[0].x;g.player.y=g.relays[0].y;g.updateRelays(6);assert.equal(g.relays[0].charge,6);g.player.x=0;g.player.y=0;g.updateRelays(10);assert.equal(g.relays[0].charge,6);g.player.x=g.relays[0].x;g.player.y=g.relays[0].y;g.updateRelays(6);assert(g.relays[0].active);const credits=g.collected;g.updateRelays(30);assert.equal(g.collected,credits);});
check('Run restoration preserves progress, build, entities and pending choices; rejects corrupt data',()=>{const g=make('engineer');g.applyUpgrade('rocket');g.t=123;g.pendingLevels=1;g.levelUp();g.spawnEnemy('spitter',200,30);const data=JSON.parse(JSON.stringify(g.serialize()));const h=make();assert(h.restore(data));assert.equal(h.state,'upgrade');assert.equal(h.t,g.t);assert.equal(h.u.rocket,1);assert.equal(h.classId,'engineer');assert.equal(h.enemies.length,g.enemies.length);assert(!h.restore({...data,player:{...data.player,hp:0}}));assert(!h.restore({...data,relays:[]}));});
check('Defeat and successful extraction finish once, with valid rewards',()=>{let outcomes=[];const g=make();g.callbacks.finish=r=>outcomes.push(r);g.player.invuln=0;g.hitPlayer(9999);g.finish(false);assert.equal(outcomes.length,1);assert(!outcomes[0].won);const w=make();w.callbacks.finish=r=>outcomes.push(r);w.t=901;w.eventIndex=w.events.length;w.finalDead=true;w.relays.forEach(r=>r.active=true);w.player.invuln=100;for(let i=0;i<303;i++)w.update(1/60);assert.equal(outcomes.length,2);assert(outcomes[1].won);assert(outcomes[1].credits>=150);});
check('Canvas rendering paths receive finite values at desktop and mobile sizes',()=>{const g=make('engineer');for(const type of ['stalker','skitter','brute','spitter','charger','splitter','elite','sentinel','final','sniper','jammer','wraith'])g.spawnEnemy(type,50,20);for(const u of ['orbit','rocket','arc','field','rail','mine'])g.applyUpgrade(u);g.pulse();g.update(1/60);g.render(1/60);g.drawMinimap(canvas);g.resize(390,844,3);g.render(1/60);g.drawMinimap(canvas);g.state='menu';g.render(1/60);assert(draws>500);});

// An immortal route follower covers the complete encounter timeline. Its build
// still has to actually kill the final boss; it cannot bypass extraction gates.
const start=performance.now();const long=make('runner');let outcome=null,peak=0,levelChoices=0;long.callbacks.finish=r=>outcome=r;
const priorities=['glass','capacitor','bastion','prism','singularity','rail','mine','nova','storm','barrage','absolute','orbit','arc','power','haste','speed','rocket','multi','pierce','field','magnet','crit','regen','vitality','armor','pulse'];
const snapshots=[];
for(let step=0;step<60*1080&&long.state!=='ended';step++){
  if(long.state==='upgrade'){const sorted=[...long.choiceSet].sort((a,b)=>priorities.indexOf(a.id)-priorities.indexOf(b.id));long.choose(sorted[0].id);levelChoices++;}
  const p=long.player;p.invuln=2;
  const relay=long.relays.find(r=>!r.active&&long.t>=r.unlock);
  const boss=long.enemies.find(e=>e.boss&&!e.dead);
  let target=relay||((long.t>=900&&long.finalDead)?{x:0,y:0}:boss?{x:boss.x+180,y:boss.y}:long.loot.find(l=>l.type==='chest')||long.loot.find(l=>l.type==='xp')||{x:Math.cos(long.t*.05)*250,y:Math.sin(long.t*.05)*250});
  let dx=target.x-p.x,dy=target.y-p.y,d=Math.hypot(dx,dy);long.touch={x:d>12?dx/d:0,y:d>12?dy/d:0};
  const aim=long.nearest(p,long.stats.range)||boss;if(aim)long.aimVector(aim.x-p.x,aim.y-p.y);
  long.activateOverdrive();
  if(long.enemies.some(e=>!e.dead&&Math.hypot(e.x-p.x,e.y-p.y)<180))long.pulse();
  long.update(1/60);peak=Math.max(peak,long.enemies.length);
  // Effects are presentation-only; prune them as the animation loop does.
  if(step%10===0){long.fx=[];long.texts=[];long.beams=[];}
  if(step%3600===0)snapshots.push({t:Math.round(long.t),lv:long.level,kills:long.kills,enemies:long.enemies.length,relays:long.relays.filter(r=>r.active).length,bosses:long.enemies.filter(e=>e.boss&&!e.dead).map(e=>[e.type,Math.round(e.hp)])});
  if(step%1200===0){assert(Number.isFinite(p.x)&&Number.isFinite(p.y)&&Number.isFinite(p.hp));assert(long.loot.length<500);assert(long.hostile.length<380);}
}
assert(outcome?.won,'full timeline did not reach a successful extraction: '+JSON.stringify(snapshots));
assert.equal(long.relays.filter(r=>r.active).length,3);assert(long.finalDead);assert.equal(long.eventIndex,long.events.length);
console.log(JSON.stringify({tests:tests.length+1,passed:tests,fullTimeline:{won:outcome.won,time:outcome.time,level:long.level,kills:long.kills,choices:levelChoices,peakEnemies:peak,evolutions:Object.keys(long.evolved),simulationSeconds:(performance.now()-start)/1000},snapshots},null,2));
